-------------------------------------
.             Credits               .
-------------------------------------


Original mod creator: AlcatrazEscapee, https://www.curseforge.com/members/alcatrazescapee

Mod link: https://www.curseforge.com/minecraft/mc-mods/no-tree-punching

Texture pack creator: @eightyfoahh


Any opinions or sugggestions? Leave a comment at the pack's page!


 //Paint 3D is a very good pixel art program :)

-------------------------------------
.            Patch Notes            .
-------------------------------------

 - v1.1:

   - A Macuahuitl new texture has been added (had no different texture before)
   - The Flint knife texture has been changed to have the same shape of the other knives already in the mod
   - The Flint shovel texture had 3 pixels tweaked; specifically the green ones, are now more bright
   - Files and archives had to been moved and organized to be compatible, but only with the 1.16+ version... Don´t put this pack in any other version, go install the 1.12+ edition if you got to!

  v1.1 update for 1.12+ probably coming soon!

 Better Flint Tools 1.16+, by @eightyfoahh

//
//


 - INSTALLATION -

It's just a resource pack, but just in case:

-First. You MUST have NoTreePunching (No way!)

-Move the .zip "Better Flint Tools" to your installation/modpack's "resourcepacks" folder (remember, Win + R, type "%appdata%", click on .minecraft folder, then "versions" and (your modpack's name)).

  //If you're new into this, remember the correct file you should move is the one with "pack.mcmeta" and "assets" inside.

-Now, go to your modpack's main folder (step 2) and search for "options.txt", open it with any program you like-

-Search for "resourcePacks:" and type Better Flint Tools like this:

resourcePacks:["Better Flint Tools.zip"]

 (free copy and paste 4 u <3)

-Boot up your modpack...



Good job! You've installed a resource pack for a mod succesfully!

 

   "Thanks, and have fun!"